


<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(Session::has('mensaje')): ?>
    <div class="alert alert-success alert-dismissible" role="alert">
    <?php echo e(Session::get('mensaje')); ?>

   <button type="button" class="close" data-dismiss="alert" arial-label="Close"></button>
      <span aria-hidden="true">&times;</span>
    </div>
    <?php endif; ?>
<a href="<?php echo e(url('/curso/create')); ?>" class="btn btn-success">Registrar Curso</a>
<br>
<br>
<table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>CODIGO</th>
            <th>NOMBRE CURSO</th>
            <th>OPCIONES</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $Cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td><?php echo e($curso->id); ?></td>
        <td><?php echo e($curso->codigo); ?></td> 
        <td><?php echo e($curso->curso); ?></td> 
        <td>
            <a href="<?php echo e(url('/curso/'.$curso->id.'/edit')); ?>" class="btn btn-primary">
                Editar
            </a>
            
         <form action="<?php echo e(url('/curso/'.$curso->id)); ?>" class="d-inline" method="post">
           <?php echo csrf_field(); ?>
           <?php echo e(method_field('DELETE')); ?>

            <input class="btn btn-danger" type="submit" onclick="return confirm('¿Quieres Eliminar?')" value="Eliminar">
        </form>
         </td> 
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Disc\Devs\Host\app-6.io\resources\views/cursos/show.blade.php ENDPATH**/ ?>